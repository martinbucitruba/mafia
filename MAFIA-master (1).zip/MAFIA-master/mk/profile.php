<?php
include('language/'._PREFIX.'/shop.php');
include('language/'._PREFIX.'/cars.php');
/*================================= PROFILE ==========================================*/
DEFINE("_P_TITLE",    			            "Профил");
DEFINE("_P_BTN1",    			            "Нападни");
DEFINE("_P_BTN2",    			            "Испрати порака");
DEFINE("_P_BTN3",    			            "Таен линк");
DEFINE("_P_BTN4",    			            "Покажи почит");
DEFINE("_P_BTN5",    			            "Пријателство");
DEFINE("_P_TAB3",    			            "Коментари");
DEFINE("_P_TAB4",    			            "Завршени мисии");
DEFINE("_P_WANTED",    			            "Има објавена сума за главата на овој човек!");
DEFINE("_P_KILLERS",   			            "Убијци");
DEFINE("_P_LEVELUP",  			            "Искуство");
DEFINE("_P_WINS",    			            "Број победи");
DEFINE("_P_LOSES",    			            "Број загуби");
DEFINE("_P_SHITS",    			            "Поени за напад");
DEFINE("_P_INFO",    			            "Информација");
DEFINE("_P_INFO2",    			            "Сопственост");
DEFINE("_P_POOR",    			            "Лицето нeма никаква сопственост!");
DEFINE("_P_RIP1",    			            "Во врска со криминалните активности ");
DEFINE("_P_RIP2",    			            " беше смртоносно застрелан! <br> Почивај во мир!");
DEFINE("_P_ERROR99",        			    "Нема напишани коментари!");
DEFINE("_P_ERROR98",        			    "Нема коли во гаражата");
/*=====*/
DEFINE("_P_COMM_INFO",    			        "Напиши коментар и кликни 'Остави!'");
DEFINE("_DELLETE",    			        	"Избриши");
DEFINE("_P_COMM_BTN1",    			        "Остави!");
DEFINE("_ADDED_FROM",    			        "Додаден од: ");
DEFINE("_ON_DATE",    			       		"на :");
DEFINE("_NO_PERMITION",    			       	"Немаш дозвола да го избришеш овој коментар!");
DEFINE("_COMMENT_DELETED",    			    "Коментарот е успешно избришан.");
DEFINE("_COMMENT_ADDED",    			    "Коментарот е успешно додаден.");
/*=====*/
DEFINE("_P_MISS_TITLE1",    			    "Туторијали");
DEFINE("_P_MISS_TITLE2",    			    "Мисии за напреднати");
DEFINE("_P_MISS_TITLE3",    			    "Мисии за експерти");
DEFINE("_P_MISS_EMPTY",    			        "Мафијашот нема извршено мисии од оваа категорија.");
/*=== WANTED ===*/
DEFINE("_P_W_TITLE",    			        "СЕ БАРА!");
DEFINE("_P_W_INFO1",    			        "Почитувани колеги,<br><br> Објавувам награда за главата на");
DEFINE("_P_W_INFO2",    			        "Наградата е:");
DEFINE("_P_W_INFO3",    			        "Од");
DEFINE("_RACE_COL3",    			        "Вредност");
DEFINE("_P_WAITING",    			        "Чека да биде одобрен");
DEFINE("_P_LEAVE",    			      		"Напушти ја фамилијата");
?>