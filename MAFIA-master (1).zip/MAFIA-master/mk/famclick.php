<?php
DEFINE("_FCL_ITEM1",			   		" веќе има ");
DEFINE("_FCL_ITEM2",			   		" oбучени убијци!");
DEFINE("_FCL_ITEM3",			   		"Веќе си платен убиец за денес. Утре, пробај пак!");
?>