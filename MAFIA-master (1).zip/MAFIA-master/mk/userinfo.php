<?php 
DEFINE("_CASH",					" Кеш");
DEFINE("_BANK",					" Финансии");
DEFINE("_BANKUP",			    " Банка");
DEFINE("_POWER",			 	" Моќ");
DEFINE("_HEALTH",				" Здравје");
DEFINE("_RANG",                 " Ранг");
DEFINE("_CITY",	        		" Град");
DEFINE("_HIDDEN",	            " Скриен");
DEFINE("_MONEYPREFIX",			"&nbsp;€&nbsp;");
?>