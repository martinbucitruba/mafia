<?php
/*=================================  NEWS  ==========================================*/
DEFINE("_NEWS_TITLE1",					"Последни новости");
DEFINE("_NEWS_TITLE2",					"Приватни пораки");
DEFINE("_NEWS_TITLE3",					"Последно од форумот");
DEFINE("_NEWS_TITLE4",					"Мојот профил");
DEFINE("_NEWS_TITLE5",					"Будни мафијаши во моментот");
DEFINE("_NEWS_TITLE6",					"Топ 5");
DEFINE("_NEWS_COL1",	 				"Наслов");
DEFINE("_NEWS_COL2",    			    "Автор");
DEFINE("_NEWS_COL3",					"Дата");
DEFINE("_NEWS_TOP1",	 				"Топ 5 играчи");
DEFINE("_NEWS_TOP2",    			    "Убиства");
DEFINE("_NEWS_TOP3",					"Почит");
DEFINE("_NEWS_TOP4",					"Платени убијци");
DEFINE("_MYSECRETLINK2",				"Информација");
DEFINE("_MYSECRETLINKINFO",				"Ако некој го посети твојот таен линк ти добиваш еден платен убиец, 100 € кеш и 500 € на твојата банкарска сметка!");
DEFINE("_NEWS_FORUM_ALL",				"Сите теми");
DEFINE("_NEWS_INBOX_ALL",				"Сите пораки");
DEFINE("_NEWS_INBOX_EMPTY",				"Немаш нови пораки");
DEFINE("_EXPIRIENCE",				    "Искуство");
DEFINE("_P_KILLERS",   			        "Убијци");
DEFINE("_P_WINS",    			        "Број победи");
DEFINE("_P_LOSES",    			        "Број загуби");
DEFINE("_P_SHITS",    			       	"Поени за напад");
DEFINE("_KILLS",    			       	"Убиства");
DEFINE("_LEFT_LIVES",    			    "Преостанати животи");
?>