<?php
/*================================= FAMILY PROFILE ==========================================*/
DEFINE("_FP_FOUNDER",				   	"Основач");
DEFINE("_FP_MEMBERS",				    "Членови");
DEFINE("_MAX",							"Максимален број ");
DEFINE("_FP_LEAVE",						"Напушти ја фамилијата");
DEFINE("_FP_DONATION",					"Донација");
DEFINE("_FP_NOTHING",				   	"Фамилијата нема никаква сопственост");
DEFINE("_FP_RANG",				   		"Ранг во фамилијата");
DEFINE("_FP_MOTO",						"Мото");

DEFINE("_F_ITEM1",				   		"Хотели");
DEFINE("_F_ITEM2",				   		"Моќ за фамилијата");
DEFINE("_F_ITEM3",				   		"Воени бродови");
DEFINE("_F_ITEM4",				   		"Носачи на авиони");
DEFINE("_F_ITEM5",				   		"Бомби 'Daisy cutter'");
DEFINE("_F_ITEM6",				   		"Минофрлачи");
DEFINE("_F_ITEM7",				   		"Тенкови");
DEFINE("_F_ITEM8",				   		"Хеликоптери");
DEFINE("_F_ITEM9",				   		"Воени ловци");
DEFINE("_P_KILLERS",   			            "Убијци");
DEFINE("_P_WINS",    			            "Број победи");
DEFINE("_P_LOSES",    			            "Број загуби");
DEFINE("_P_BTN3",    			            "Таен линк");
DEFINE("_P_INFO2",    			            "Сопственост");
DEFINE("_P_BTN1",    			            "Нападни");
DEFINE("_SHOP_ITEM14",    			        "Поени за напад");
DEFINE("_RACE_COL3",    			        "Вредност");
DEFINE("_NO_FAMILIES",    			    "Сè уште нема оформени фамилии...");
?>